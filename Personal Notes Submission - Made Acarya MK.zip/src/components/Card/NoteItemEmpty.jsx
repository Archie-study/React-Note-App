import React from "react";

function NoteItemEmpty() {
    return (
        <p className="notes-list__empty-message">Tidak ada catatan</p>
    )
}

export default NoteItemEmpty;